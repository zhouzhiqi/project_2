# coding: utf-8

# filelist: 
#         train:40428967,  
#     minitrain:4042898,  
# miniminitrain:404291,  
#    test_click:4577464
#  

#import os
#os.chdir('/media/zhou/0004DD1700005FE8/AI/00/project_2/')
#os.chdir('E:/AI/00/project_2')

try: 
    from tinyenv.flags import flags
except ImportError:
    # 若在本地运行，则自动生成相同的class
    class flags(object):
        def __init__(self):
            self.file_name = 'minitrain'
            self.onehot_name = 'Onehot_A'
            self.data_dir = '../data/project_2/data/{0}/'.format(self.onehot_name)
            self.output_dir = '../data/project_2/output/{0}/'.format(self.onehot_name)
            self.model_dir = '../data/project_2/models/{0}/'.format(self.onehot_name)

class params(object):
    def __init__(self, ):
        self.threshold = 10
        self.chunksize = 1e3
        self.num_trees = 50
        self.deep = 8
        self.split = '='

#实例化class
FLAGS = flags()
PARAMS = params()

import numpy as np
import pandas as pd
import time
import gc
import os
import scipy.sparse as ss
#from  sklearn.cross_validation  import  train_test_split 
#import xgboost as xgb
import tarfile
from multiprocessing import Pool
import pickle as pickle

def GetC17IIndex(data_path, ):
    print('get C17s ')
    C17 = pd.read_csv(data_path+'train.csv', usecols=[19],)
    C17s = C17.loc[:,'C17'].value_counts()
    C17s = C17s.index.map(lambda x : 'C17=' + str(x))
    #C17_index = pd.Series(index=C17s, data=np.arange(4,435+4))
    del C17
    gc.collect()
    return C17s

class ClickHistory(object):
    
    def __init__(self, param, ):
        data_path = param['data_path']  #数据路径
        file_name = param['file_name']  #待处理文件名
        chunksize = param['chunksize']  #迭代读取数据量
        output_path = param['output_path']  #输出文件夹
        day = param['day']  #待处理的那一天
        C17s = param['C17s']  #对C17进行编码, 'C17=' + str(values)

        #C17s = self.GetC17IIndex(data_path)
        for hour in range(24):
            one_hour = self.GetOneHour(data_path, file_name, chunksize, day, hour)
            self.GetHistory(output_path, one_hour, day, hour, C17s)
        #self.click_history.to_csv(data_path+'click_history_day{0}.csv'.format(day), index=False)

    def LoadData(self, data_path, file_name):
        print('load data')
        self.total_size = 0  #已经读取的数据量
        self.data_over = False  #数据是否读取完全
        data = pd.read_csv(data_path+'{0}.csv'.format(file_name), 
                           usecols=[1,2,3,4,11,12,13,19],
                           iterator=True)
        return data

    def NextChunk(self, data, chunksize):
        """获取 chunksize 条数据"""
        #0.4M条数据用时44min, 改变chunksize基本不会影响处理速度
        try: data_tmp = data.get_chunk(chunksize)  #每次读取chunk_size条数据 
        except StopIteration: self.data_over = True  #读取结束后跳出循环
        else: 
            self.total_size += data_tmp.shape[0]  #累加当前数据量
            return data_tmp  #返回取出的数据

    def DayHourUserC17(self, data, day, hour):
        """把传入的数据转为['click', 'hour', 'day', 'user', 'C17']"""
        # 重新定义columns
        data.columns = ['click', 'hour', 'day', 'user', 'device_id', 'device_ip', 'device_model', 'C17']
        # 处理得到 某一天
        data.loc[:,'day'] = data.loc[:, 'hour'].values %14100000 //100
        # 处理得到 这一天的小时
        data.loc[:,'hour'] = data.loc[:, 'hour'].values %14100000 %100
        # 处理得到 'C17=' + str(values)        
        data.loc[:, 'C17'] = 'C17=' + data.loc[:, 'C17'].astype(np.str)
        # 处理得到 user
        data.loc[:,'user'] = data.loc[:, 'device_id'].values
        index = data.loc[:, 'device_id']=='a99f214a'
        data.loc[index, 'user'] = data.loc[index, 'device_ip']  + '&' + data.loc[index, 'device_model']

        return data  #返回处理后结果

    def MergeOneHour(self, data, day, hour):
        """取出某一天的数据"""
        index = (data.loc[:, 'day']==day) & (data.loc[:, 'hour']==hour)  #获得索引
        return data.loc[index, :]  #返回取出结果

    def GetOneHour(self, data_path, file_name, chunksize, day, hour):
        """循环读取数据, 处理拼接, 得到某一天的HourUserC17"""
        print('-----------------------')
        print('get day:{0}, hour:{1}'.format(day, hour))  
        data = self.LoadData(data_path, file_name,)  #读取指定列的数据

        #data_tmp = self.NextChunk(data, chunksize)  #读取一定数量的数据
        #data_tmp = self.DayHourUserC17(data_tmp, day, hour)  #处理成DayHourUserC17
        Onehour = pd.DataFrame(columns=['click', 'hour', 'day', 'user', 
                    'device_id', 'device_ip', 'device_model', 'C17'])   #取出指定日期的处理后的数据
        while True:
            #if self.total_size >= 1e6: break  #先判断数据量是否足够, 若足够, 训练结束
            data_tmp = self.NextChunk(data, chunksize)  #每次读取chunk_size条数据 
            if self.data_over: break #数据读取结束, 训练结束
            data_tmp = self.DayHourUserC17(data_tmp, day, hour)
            Onehour = pd.concat((Onehour, self.MergeOneHour(data_tmp, day, hour)),axis=0)
            #print(Onehour.shape)
        return Onehour  #返回整个数据中, 日期为day的, 处理为DayHourUserC17的数据 

    def GetHistory(self, output_path, data, day, hour,  C17s):
        """对日期为day的, 处理后的数据, 按user进行统计, 以得到点击历史"""
        # 生成指定列的列名
        columns = pd.Index(['hour', 'user','click_times', 'total_times']).append(C17s)
        # 生成指定列名的空的df, 用于和下面每个小时的结果合并
        #click_history = pd.DataFrame(columns=columns,)#data=np.zeros((1,columns.shape[0]),dtype=np.uint16))
        d = day
        h = hour
        start_time = time.time()
        # 取出指定日期, 指定时间的 DayHourUserC17
        day_hour = data.loc[(data.loc[:, 'day']==d) & (data.loc[:, 'hour']==h),:]
        # 对user进行计数, 
        users = day_hour.loc[:,'user'].value_counts()
        # 生成以user作为索引, 0,1,2,3...作为values, 用作下面循环的索引
        users = pd.Series(index=users.index, data=np.arange(users.shape[0]))
        # 生成指定列名的空的暂存的df, 用于和初始的空的df合并
        click_history_hour = pd.DataFrame(columns=columns,data=np.zeros((users.shape[0], columns.shape[0]),dtype=np.uint16))
        # 对指定日期, 指定时间的所有user, 进行点击历史的统计
        for u in users.index:
            i = users[u]
            # 生成指定日期, 指定时间, 指定user 的索引
            index = (day_hour.loc[:, 'day']==d) & (day_hour.loc[:, 'hour']==h) & (day_hour.loc[:, 'user']==u) 
            # 生成指定日期, 指定时间, 指定user 的DayHourUserC17
            data_tmp = day_hour.loc[index, :]
            # 如果找到的指定信息的数据为空, 结束本次处理
            if data_tmp.shape[0]==0: continue
            # 如果找到的指定信息的数据不为空, 把指定信息的数据, 填入指定位置
            click_history_hour.loc[i,'hour'] = h  #时间
            click_history_hour.loc[i,'user'] = u  #user
            # 指定日期, 指定时间, 指定user的 点击次数
            click_history_hour.loc[i,'click_times'] = data_tmp.loc[:,'click'].sum()  
            # 指定日期, 指定时间, 指定user的 浏览次数
            click_history_hour.loc[i,'total_times'] = data_tmp.shape[0]
            # 指定日期, 指定时间, 指定user的 感兴趣的C17
            C17_count = data_tmp.loc[:,'C17'].value_counts()
            for c17 in C17_count.index:  #逐个C17进行填写
                click_history_hour.loc[i,c17] += C17_count[c17]
        # 与原有的df 进行拼接
        click_history_hour.to_csv(output_path+'click_history_day{0}_hour{1}.csv'.format(day, hour), index=False)
        # 输出所用时间
        used_time = int(time.time()-start_time)
        print('day[{0}] in hour[{1}], total time:{2}'.format(d, h, used_time),)
        #return click_history  #返回指定日期内, 所有user的, 点击历史的统计



def MergeOneDay(self, data, day):
    """取出某一天的数据"""
    index = data.loc[:,'day'] == day  #获得索引
    return data.loc[index, :]  #返回取出结果

def GetOneDay(self, data_path, file_name, chunksize, day,):
    """循环读取数据, 处理拼接, 得到某一天的HourUserC17"""
    data = self.LoadData(data_path, file_name,)  #读取指定列的数据
    data_tmp = self.NextChunk(data, chunksize)  #读取一定数量的数据
    data_tmp = self.DayHourUserC17(data_tmp, day)  #处理成DayHourUserC17
    Oneday = self.MergeOneDay(data_tmp, day)   #取出指定日期的处理后的数据
    while True:
        #if self.total_size >= 1e6: break  #先判断数据量是否足够, 若足够, 训练结束
        data_tmp = self.NextChunk(data, chunksize)  #每次读取chunk_size条数据 
        if self.data_over: break #数据读取结束, 训练结束
        data_tmp = self.DayHourUserC17(data_tmp, day)
        Oneday = pd.concat((Oneday, self.MergeOneDay(data_tmp, day)),axis=0)
        #print(Oneday.shape)
    return Oneday  #返回整个数据中, 日期为day的, 处理为DayHourUserC17的数据 

def GetHistory(self, data, day, C17s):
    """对日期为day的, 处理后的数据, 按user进行统计, 以得到点击历史"""
    # 生成指定列的列名
    columns = pd.Index(['hour', 'user','click_times', 'total_times']).append(C17s)
    # 生成指定列名的空的df, 用于和下面每个小时的结果合并
    click_history = pd.DataFrame(columns=columns,)#data=np.zeros((1,columns.shape[0]),dtype=np.uint16))
    d = day
    start_time = time.time()
    # 对24小时, 逐一进行处理
    for h in range(24):
        # 取出指定日期, 指定时间的 DayHourUserC17
        day_hour = data.loc[(data.loc[:, 'day']==d) & (data.loc[:, 'hour']==h),:]
        # 对user进行计数, 
        users = day_hour.loc[:,'user'].value_counts()
        # 生成以user作为索引, 0,1,2,3...作为values, 用作下面循环的索引
        users = pd.Series(index=users.index, data=np.arange(users.shape[0]))
        # 生成指定列名的空的暂存的df, 用于和初始的空的df合并
        click_history_hour = pd.DataFrame(columns=columns,data=np.zeros((users.shape[0], columns.shape[0]),dtype=np.uint16))
        # 对指定日期, 指定时间的所有user, 进行点击历史的统计
        for u in users.index:
            i = users[u]
            # 生成指定日期, 指定时间, 指定user 的索引
            index = (day_hour.loc[:, 'day']==d) & (day_hour.loc[:, 'hour']==h) & (day_hour.loc[:, 'user']==u) 
            # 生成指定日期, 指定时间, 指定user 的DayHourUserC17
            data_tmp = day_hour.loc[index, :]
            # 如果找到的指定信息的数据为空, 结束本次处理
            if data_tmp.shape[0]==0: continue
            # 如果找到的指定信息的数据不为空, 把指定信息的数据, 填入指定位置
            click_history_hour.loc[i,'hour'] = h  #时间
            click_history_hour.loc[i,'user'] = u  #user
            # 指定日期, 指定时间, 指定user的 点击次数
            click_history_hour.loc[i,'click_times'] = data_tmp.loc[:,'click'].sum()  
            # 指定日期, 指定时间, 指定user的 浏览次数
            click_history_hour.loc[i,'total_times'] = data_tmp.shape[0]
            # 指定日期, 指定时间, 指定user的 感兴趣的C17
            C17_count = data_tmp.loc[:,'C17'].value_counts()
            for c17 in C17_count.index:  #逐个C17进行填写
                click_history_hour.loc[i,c17] += C17_count[c17]
        # 与原有的df 进行拼接
        click_history = pd.concat((click_history,click_history_hour), axis=0)
        # 输出所用时间
        used_time = int(time.time()-start_time)
        print('day[{0}] in hour[{1}], total time:{2}'.format(d, h, used_time),)
    return click_history  #返回指定日期内, 所有user的, 点击历史的统计


def ToPickleDump(param,):
    data_path = param['data_path']
    day = param['day']
    data_tmp = pd.read_csv(data_path+'click_history_day{0}.csv'.format(day), usecols=np.arange(2,439), dtype=np.uint16)
    data_index = pd.read_csv(data_path+'click_history_day{0}.csv'.format(day), usecols=[1], dtype=np.str).loc[:,'user'].values
    data_tmp.index = data_index
    data_dict = dict()
    total_size = data_index.shape[0]
    block_size = total_size//10
    print('day:{0}, total users:{1}'.format(day,total_size))
    start_time = time.time()
    i=0
    for u in data_tmp.index.value_counts().index:
        i += 1
        index = data_index[:] == u
        data_dict[u] = ss.csr_matrix(data_tmp.loc[index,:].sum().values)
        if (i+1)%block_size ==0:
            used_time = int(time.time()-start_time)
            print('day[{0}] in size[{1}%], total time:{2}'.format(day, int(i/total_size*100), used_time),)
    with open(data_path+'click_history_day{0}.pickl'.format(day), 'wb') as f:
        pickle.dump(data_dict, f)
    #with open(data_path+'click_history_day{0}.pickl'.format(day), 'rb') as f:
    #    test = pickle.load(f)
    #    print(test)
    
# ===========================================
# filelist: 
#         train:40428967,   count:9449445,
#     minitrain:4042898,   more_5:1544466
# miniminitrain:404291,   more_10:645381
#    test_click:4577464
# ===========================================

if __name__ == "__main__":
    
    # 解压提前压缩好的tar.gz文件, 
    # 主要用于解压上传到tinymind中的数据, 
    # 本地运行不需要解压 
    #ExtractData(FLAGS.data_dir)

    #设定参数
    #totalsize = {'minitrain':4042898, 'test_click':4577464}
    #file_size = totalsize[FLAGS.file_name]  #总的数据量
    #block_size = 100000  #数据块大小
    C17s = GetC17IIndex(FLAGS.data_dir)
    param =[dict( 
        data_path = FLAGS.data_dir,
        file_name = FLAGS.file_name,
        chunksize = PARAMS.chunksize,
        output_path = FLAGS.output_dir,
        C17s = C17s,
        day = d
                ) 
            for d in range(21,31)
            ]
    #ToPickleDump(param[5])
    #for p in param:
    #    ClickHistory(p)
    # 多进程处理onehot
    #OneHotEncoder(param[1])
    #ClickHistory(param[0])
    #MergeClickHistory666666(param[0])
    #with Pool(4) as p:  #4为进程数, 可改为更大
    #    pass
    #    p.map(ToPickleDump, param)
    with Pool(4) as p:  #4为进程数, 可改为更大
        p.map(ClickHistory, param)
    #with Pool(2) as p:  #4为进程数, 可改为更大
    #    p.map(MergeDayClickHistory, param)
    #param =[dict( 
    #data_path = FLAGS.data_dir,
    #file_name = FLAGS.file_name,)]
    #MergeAllClickHistory(param[0])
