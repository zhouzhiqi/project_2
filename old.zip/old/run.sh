#!/bin/bash

python 2_Onehot_A.py
python 2_Onehot_B.py

