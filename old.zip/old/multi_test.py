
import time
import gc
import os

x = '000123'
print('---------------')
print(hash(x))

print(id(x))

print(id(x)/hash(x))
x = '666123'
print('---------------')
print(hash(x))

print(id(x))

print(id(x)/hash(x))

 

x = 123
print('---------------')
print(hash(x))

print(id(x))

print(id(x)/hash(x))

class test(object):

    def XgboostEncoder(self, X_train, y_train, model_path,  num_trees, deep ):
        "对xgboost输出的结点位置文件, 进行onehot"
        #model_name = 'tree{0}_deep{1}.xgboost'.format(num_trees, deep)
        #生成空白onehot矩阵, 用于赋值为1,  展开后的维数:每颗树实际有2**(deep+1)个结点, deep为模型的参数max_depth
        length = 2**(deep+1)
        leaf_index = np.zeros((X_train.shape[0], num_trees*length), dtype=np.int8)
        #转为xgb专用数据格式
        print('to xgb.DMatrix')
        xgtrain = xgb.DMatrix(X_train, label = y_train,)
        #导入模型
        xgb_model = xgb.Booster(model_file=model_path + 'tree{0}_deep{1}.xgboost'.format(num_trees, deep))
        #开始预测
        print('xgboost predict . . .')
        new_feature = xgb_model.predict(xgtrain, pred_leaf=True)  #pred_leaf=True, 输出叶子结点索引
        #对新特征onehot编码
        for i in np.arange(X_train.shape[0]):
            for tree in np.arange(num_trees):  
                #tree*length是每颗树索引的区域块, 
                #new_feature[i,tree]是该颗树的叶子结点索引
                j = tree*length + new_feature[i,tree]
                leaf_index[i, j] = 1
        return ss.csr_matrix(leaf_index)